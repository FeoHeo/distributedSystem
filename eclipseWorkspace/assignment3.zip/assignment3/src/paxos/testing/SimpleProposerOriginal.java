//package paxos;
//
//import java.io.*;
//import java.net.*;
//import java.util.Map;
//import java.util.TreeMap;
//
//public class SimpleAcceptor {
//    private static int port = 5000;       // Default port
//    private static int biggestRoundId = 0; // default round Id
//    private static int nodeNum = 3;    // default numbers of node, will change to 9 later
//    private static int acceptVal = 0;
//    private static int otherPort = 5001;	// To connect to the other Acceptor
//    private static Map<Double,Integer> list = new TreeMap<> ();
//    
//    
//    private static void log(String message) {
//        System.out.println(String.format("[Acceptor-%d] %s", port, message));
//    }
//    
//    public static boolean handle_prepare(int roundId) {
//        if(roundId > biggestRoundId) {
//            log("Updating biggest round from " + biggestRoundId + " to " + roundId);
//            biggestRoundId = roundId;
//            return true;
//        } else {
//            return false;    
//        }
//    }
//    
//    public static void send_promise(PrintWriter outStream, int roundId) {
//        log("Sending Promise for round " + roundId);
//        outStream.println("Promise:" + roundId);
//    }
//    
//    public static void send_accept(PrintWriter outStream, int acceptId , PrintWriter otherOut) {
//        log("Sending Accept confirmation for value " + acceptId);
//        outStream.println("Confirmed:" + acceptId + ":" + biggestRoundId);
//        otherOut.println("Confirmed:" + acceptId + ":" + biggestRoundId);
//    }
//    
//    public static void connect_node() {
//    	
//    }
//    
//    public static void main(String[] args) {	// For connection with Proposer
//        SimpleAcceptor obj = new SimpleAcceptor();
//        
//        if(args.length > 0) {
//            port = Integer.parseInt(args[0]);
//            if(args.length > 1) {
//                nodeNum = Integer.parseInt(args[1]);
//            }
//        } else {
//            log("Using default port " + port);
//        }
//            
//        try (ServerSocket serverSocket = new ServerSocket(port)) {
//            log("Server is listening on port " + port + " with starting round id: " + biggestRoundId);
//            
//            try (	
//                Socket clientSocket = serverSocket.accept();
//                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
//                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
//            	
//            ) {
//                log("New client connected from " + clientSocket.getRemoteSocketAddress());
//                
//                // Stuff for sending out confirm msg
//                Socket outSocket = null;
//                boolean connected = false;
//
//                	
//                while (!connected) {
//                    try {
//                        outSocket = new Socket("localhost", otherPort);
//                        connected = true;
//                    } catch (ConnectException e) {
//                        log("Waiting for other acceptor to start...");
//                    }
//                }
//                Socket inSocket = serverSocket.accept();
//                final PrintWriter acptOut = new PrintWriter(outSocket.getOutputStream() , true);
//                final BufferedReader acptIn = new BufferedReader(new InputStreamReader(inSocket.getInputStream()));
//                
//                Thread responseThread = new Thread (() -> {
//                	try {
//                		// Handling other Acceptors
//                		String inputAcpt;
//                		acptOut.println("Ping from " + port + " node num " + (port%10 + 1));
//                		while((inputAcpt = acptIn.readLine()) != null) {
//            				if(inputAcpt.startsWith("Confirmed")) {	
//            					String[] logArr = inputAcpt.split(":");		// logArr[1] contain round number, [2] contain val and [0] is "Confirmed"
//            					Double roundInfo = Double.parseDouble(logArr[1]) + (otherPort % 10);
//            					Integer valInfo = Integer.parseInt(logArr[2]);
//            					list.put(roundInfo, valInfo);
//            					out.println("Confirmed:"+logArr[1]+":"+logArr[2]);
//            					log("Stored round "+roundInfo+" with value "+valInfo);
//            				} else {
//            					log(inputAcpt);
//            				}
//                			
//                		}
//                	} catch (IOException e) {
//                		// TODO Auto-generated catch block
//                		e.printStackTrace();
//                	} finally {
//                		log("Connection finished");
//                	}
//                });
//                
//                responseThread.start();
//
//                
//                String inputLine;
//                while ((inputLine = in.readLine()) != null) {
//                    log("Received: " + inputLine);
//                    
//                    // Handling Proposer
//                    String[] arr = inputLine.split(":");
//                    if (inputLine.startsWith("Prepare")) {
//                        int receivedRoundId = Integer.parseInt(arr[1]);
//                        log("Received Prepare with round ID: " + receivedRoundId);
//                        
//                        if(handle_prepare(receivedRoundId)) {
//                            log("Sending promise for round " + receivedRoundId);
//                            send_promise(out, receivedRoundId);
//                        } else {
//                            log("Rejecting round " + receivedRoundId + " (current biggest round: " + biggestRoundId + ")");
//                            out.println("Reject");
//                        }
//                        
//                    } else if(inputLine.startsWith("Accept")) {
//                        acceptVal = Integer.parseInt(arr[1]);
//                        log("Received Accept with value: " + acceptVal);
//                        send_accept(out, acceptVal , acptOut);
//                    } else {
//                        // Echo other messages
//                        out.println("Server echoes: " + inputLine);
//                    }
//                    
//                    
//                }
//                
//                
//            } catch (IOException e) {
//                log("Exception handling client: " + e.getMessage());
//            }
//        } catch (IOException e) {
//            log("Server exception: " + e.getMessage());
//        }
//    }
//}

